package com.qwer.qwer.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.qwer.qwer.dto.BoardDto;

@Mapper
public interface BoardDao {

	@Select("select * from testboard order by b_date")
	List<BoardDto> getBoardList(BoardDto bDto);

	@Insert("INSERT INTO TESTBOARD VALUES(NULL,#{b_title},#{b_contents},#{b_writer},DEFAULT,DEFAULT)")
	int insertDummyData(BoardDto bDto);

}
