package com.qwer.qwer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QwerApplicationTests {

	@Test
	void contextLoads() {
	}

}
